<div class="leftpane">
		<ul class="menu">
			<li class="active"><a href="#">Add Manufacturer</a></li>
			<li><a href="model.php">Add Car Model</a></li>
			<li><a href="view.php">View Inventory</a></li>
		</ul>
	</div>